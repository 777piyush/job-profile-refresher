# job-profile-refresher
Naukri automation driven by `tasks.yml`. Edit that one file to change what runs.
- `dry_run: true` fills forms and takes screenshots without saving. Set to false when happy.
- Runs daily at 9:00 AM IST on a self-hosted runner (your Mac, must be on and awake).
- CTC/salary is never touched.
- Local test: `HEADLESS=0 python naukri_refresh.py`
